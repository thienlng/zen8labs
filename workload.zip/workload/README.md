# VTNet workload

## On local

```bash
$ kind create cluster --config ./kind-cluster.yaml
```
